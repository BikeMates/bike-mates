﻿namespace BikeMates.Domain.Entities
{
    public class Coordinate : Entity
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
    }
}
